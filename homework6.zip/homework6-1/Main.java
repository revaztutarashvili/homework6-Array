public class Main {

    public static void main(String[] args) {
        // სტრინგების მასივის ინიციალიზაცია პირდაპირ
        String[] words = {"ვაშლი", "მსხალი", "ფორთოხალი", "ბანანი", "ატამი", "საზამთრო", "ნესვი", "კივი", "მანგო", "ალუბალი"};

        /**
        მასივზე გადავლა for-each loop-ით და თითოეული სიტყვის დაბეჭდვა
        */ 
        for (String word : words) {
            System.out.println(word);
        }

    }
}