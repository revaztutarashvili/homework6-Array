public class Find {
    public static void findAndPrintIndex(int[] antuni, int number) {
        for (int i = 0; i < antuni.length; i++) {
            if (antuni[i] == number) {
                System.out.println("\nგილოცავთ, რიცხვი " + number + " ვიპოვნეთ ინდექსზე " + i);
                return;
            }
        }
        System.out.println("\nსამწუხაროდ, ვერ ვიპოვეთ " + number);
    }
}