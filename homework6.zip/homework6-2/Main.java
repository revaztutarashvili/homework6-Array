import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        // რიცხვის მასივი 
        int[] numbers = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

        System.out.println("გთხოვთ შეიყვანოთ რიცხვი 1 დან 100 მდე() 10,20,30 და ა.შ.");

        //მომხმარებელს შეჰყავს სასურველი რიცხვი. 
        int inputNumber = scanner.nextInt();

        // მეთოდის გამოძახება
        Find.findAndPrintIndex(numbers, inputNumber);

    }
}